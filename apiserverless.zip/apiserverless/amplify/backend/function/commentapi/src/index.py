import awsgi
import boto3
import os

from flask_cors CORS 
from flask import Flask, jsonify, request
from uuid import uuid4

main_route = "/comment"
table = os.environ.get("")

client = boto3.client(dynamodb)

app = Flask(__name__)

CORS(app)

@app.route(main_route, methods=['POST'])
def add_comment():

    request_json = request.get_json()
    client.put_item(TableName= table, item=>{
        'id': {'S': str(uuid4())},
        'user_id':{'S': request_json.get('user_id')},
        'parent_id':{'S': request_json.get('Parent_id')},
        'user_name':{'S': request_json.get('user_name')},
        'text':{'S': request_json.get('text')},
        'processedtext':{'S': request_json.get('processedtext')},
        'country':{'S': request_json.get('country')},
        'language':{'S': request_json.get('language')},
        'flag':{'S': request_json.get('flag')}

    })
    return jsonify(message="item created")

@app.route(main_route + '/<user_id>', methods=['GET'])
def add_comment(user_id):
    comment = client.get_item(TableName=table, Key={
        'id':{
            's':user_id
        }
    })
    return jsonify(data=song)   


@app.route(main_route + '/<user_id>'+'/comment_id', methods=['GET'])
def delete_comment(user_id, comment_id):
    client.delete_item(
        TableName=table,
        Key={'user_id':{'s': user_id }, 'comment_id':{'s':comment_id}
    })
    return jsonify(message='comment deleted')   

@ 

@app.route(main_route, methods=['GET'])
def get_comments():
    return jsonify(data=client.scan(TableName=table))

def handler(event, context):
    return awsgi.response(app, event, context)